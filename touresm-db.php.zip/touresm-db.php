<?php
/**
 * Plugin Name: Touresm DB Layer
 * Description: Custom tables + PODs sync + Full REST API for Touresm Listings & Bookings.
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) exit;

class Touresm_DB_Layer {

    public function __construct() {
        register_activation_hook(__FILE__, [$this, 'activate']);

        // Sync PODs → DB
        add_action('pods_api_post_save_pod_item_touresm-listing', [$this, 'sync_listing'], 10, 3);
        add_action('pods_api_post_save_pod_item_listing_booking', [$this, 'sync_booking'], 10, 3);

        // REST API
        add_action('rest_api_init', [$this, 'api_routes']);
    }

    /* -------------------------------------------------------
     * 1) INSTALL TABLES
     * ------------------------------------------------------- */
    public function activate() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        $listings = $wpdb->prefix . 'touresm_listings';
        $bookings = $wpdb->prefix . 'touresm_bookings';

        $sql1 = "CREATE TABLE $listings (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            listing_post_id BIGINT UNSIGNED NOT NULL,
            listing_name VARCHAR(255),
            room_number INT,
            listing_bed_number INT,
            guest_max_number INT,
            listing_description LONGTEXT,
            listing_price DECIMAL(10,2),
            check_in_time VARCHAR(50),
            check_out_time VARCHAR(50),
            listing_gallery LONGTEXT,
            listing_social_url VARCHAR(255),
            listing_familiar_location VARCHAR(255),
            listing_video VARCHAR(255),
            admin_blocked_days LONGTEXT,
            host_blocked_days LONGTEXT,
            size_term_id BIGINT UNSIGNED NULL,
            location_term_id BIGINT UNSIGNED NULL,
            category_term_id BIGINT UNSIGNED NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uq_listing (listing_post_id)
        ) $charset;";

        $sql2 = "CREATE TABLE $bookings (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            booking_post_id BIGINT UNSIGNED NOT NULL,
            related_listing_post_id BIGINT UNSIGNED NOT NULL,
            customer_name VARCHAR(255),
            customer_mobile VARCHAR(50),
            check_in_date DATE,
            check_out_date DATE,
            guest_number INT,
            booking_description LONGTEXT,
            paid_amount DECIMAL(10,2),
            paid_receipt VARCHAR(255),
            confirmation_status VARCHAR(50),
            confirmation_date DATETIME NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            KEY idx_listing (related_listing_post_id),
            KEY idx_checkin (check_in_date)
        ) $charset;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql1);
        dbDelta($sql2);
    }

    private function get_tax_term($post_id, $taxonomy) {
        $terms = wp_get_post_terms($post_id, $taxonomy, ['fields'=>'ids']);
        return (!empty($terms) && !is_wp_error($terms)) ? (int)$terms[0] : null;
    }

    /* -------------------------------------------------------
     * 2) SYNC PODS → CUSTOM TABLE (LISTING)
     * ------------------------------------------------------- */
    public function sync_listing($pieces, $is_new, $post_id) {
        global $wpdb;

        $pod = pods('touresm-listing', $post_id);
        if (!$pod) return;

        $table = $wpdb->prefix . 'touresm_listings';

        $wpdb->replace($table, [
            'listing_post_id' => $post_id,
            'listing_name' => $pod->field('listing_name'),
            'room_number' => $pod->field('room_number'),
            'listing_bed_number' => $pod->field('listing_bed_number'),
            'guest_max_number' => $pod->field('guest_max_number'),
            'listing_description' => $pod->field('listing_description'),
            'listing_price' => $pod->field('listing_price'),
            'check_in_time' => $pod->field('check_in_time'),
            'check_out_time' => $pod->field('check_out_time'),
            'listing_gallery' => maybe_serialize($pod->field('listing_gallery')),
            'listing_social_url' => $pod->field('listing_social_url'),
            'listing_familiar_location' => $pod->field('listing_familiar_location'),
            'listing_video' => $pod->field('listing_video'),
            'admin_blocked_days' => maybe_serialize($pod->field('admin_blocked_days')),
            'host_blocked_days' => maybe_serialize($pod->field('host_blocked_days')),
            'size_term_id' => $this->get_tax_term($post_id, 'listing_size'),
            'location_term_id' => $this->get_tax_term($post_id, 'listing_location'),
            'category_term_id' => $this->get_tax_term($post_id, 'listing_category'),
        ]);
    }

    /* -------------------------------------------------------
     * 3) SYNC PODS → CUSTOM TABLE (BOOKING)
     * ------------------------------------------------------- */
    public function sync_booking($pieces, $is_new, $post_id) {
        global $wpdb;

        $pod = pods('listing_booking', $post_id);
        if (!$pod) return;

        $table = $wpdb->prefix . 'touresm_bookings';

        $wpdb->replace($table, [
            'booking_post_id' => $post_id,
            'related_listing_post_id' => $pod->field('related_listing'),
            'customer_name' => $pod->field('customer_name'),
            'customer_mobile' => $pod->field('customer_mobile'),
            'check_in_date' => $pod->field('check_in_date'),
            'check_out_date' => $pod->field('check_out_date'),
            'guest_number' => $pod->field('guest_number'),
            'booking_description' => $pod->field('booking_description'),
            'paid_amount' => $pod->field('paid_amount'),
            'paid_receipt' => $pod->field('paid_receipt'),
            'confirmation_status' => $pod->field('confirmation_status'),
            'confirmation_date' => $pod->field('confirmation_date'),
        ]);
    }

    /* -------------------------------------------------------
     * 4) REST API (FULL)
     * ------------------------------------------------------- */
    public function api_routes() {

        register_rest_route('touresm/v1', '/listings', [
            'methods' => 'GET',
            'callback' => [$this, 'api_get_listings'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route('touresm/v1', '/listing/(?P<id>\d+)', [
            'methods' => 'GET',
            'callback' => [$this, 'api_get_listing_details'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route('touresm/v1', '/listing/(?P<id>\d+)/bookings', [
            'methods' => 'GET',
            'callback' => [$this, 'api_get_listing_bookings'],
            'permission_callback' => '__return_true'
        ]);

        register_rest_route('touresm/v1', '/booking', [
            'methods' => 'POST',
            'callback' => [$this, 'api_create_booking'],
            'permission_callback' => '__return_true'
        ]);
    }

    /* -------- API Handlers ---------- */

    public function api_get_listings() {
        global $wpdb;
        return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}touresm_listings", ARRAY_A);
    }

    public function api_get_listing_details($req) {
        global $wpdb;
        $id = (int)$req['id'];
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}touresm_listings WHERE listing_post_id = %d", $id),
            ARRAY_A
        );
    }

    public function api_get_listing_bookings($req) {
        global $wpdb;
        $id = (int)$req['id'];
        return $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}touresm_bookings WHERE related_listing_post_id = %d", $id),
            ARRAY_A
        );
    }

    public function api_create_booking($req) {
        global $wpdb;

        $data = [
            'related_listing_post_id' => $req['related_listing'],
            'customer_name' => $req['customer_name'],
            'customer_mobile' => $req['customer_mobile'],
            'check_in_date' => $req['check_in_date'],
            'check_out_date' => $req['check_out_date'],
            'guest_number' => $req['guest_number'],
            'booking_description' => $req['booking_description'],
            'paid_amount' => $req['paid_amount'],
            'paid_receipt' => $req['paid_receipt'],
            'confirmation_status' => 'pending'
        ];

        $wpdb->insert($wpdb->prefix.'touresm_bookings', $data);

        return [
            'success' => true,
            'booking_id' => $wpdb->insert_id
        ];
    }
}

new Touresm_DB_Layer();